# -*- coding: utf-8 -*-
"""
Sistema de chatbot para roteiro de dispensação
"""