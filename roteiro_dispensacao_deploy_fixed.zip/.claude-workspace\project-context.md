# CONTEXTO COMPLETO - SITE ROTEIRO DE DISPENSAÇÃO

## PERSONAS CRÍTICAS (NÃO ALTERAR)
### Dr. Gasnelio
- Farmacêutico especialista, linguagem técnica
- Avatar: https://i.postimg.cc/NfdHCVM7/Chat-GPT-Image-13-de-jul-de-2025-00-09-29.png
- Público: Profissionais de saúde

### Gá
- Amigo farmacêutico, linguagem simples
- Avatar: https://i.postimg.cc/j5YwJYgK/Chat-GPT-Image-13-de-jul-de-2025-00-14-18.png  
- Público: Pacientes e leigos

## REGRAS CLAUDE CODE
1. SEMPRE preservar funcionalidade das personas
2. SEMPRE validar antes de fazer mudanças
3. SEMPRE usar scripts de automação
4. NUNCA quebrar integração com APIs existentes
