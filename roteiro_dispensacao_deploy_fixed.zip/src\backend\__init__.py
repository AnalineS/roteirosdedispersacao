# -*- coding: utf-8 -*-
"""
Módulo backend do sistema de chatbot
"""