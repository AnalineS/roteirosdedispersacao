import sys
import os
from dotenv import load_dotenv

# Configurar diretório do projeto
project_home = '/home/roteirodedispensacao'
if project_home not in sys.path:
    sys.path.insert(0, project_home)

# Carregar arquivo .env
load_dotenv(os.path.join(project_home, '.env'))

# Importar aplicação Flask
from app_flask import app as application